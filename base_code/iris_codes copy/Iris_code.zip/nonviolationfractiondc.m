function [fracInBounds, out_bounds, avg_cap] = nonviolationfractiondc(pwr_case, pv_cap, irrad_time,...
    pct_load, dc_power, dc_ratio, dc_cap, options, dcBus, numBuses)

pvBus = 7;
numLoads = 10;

out_bounds = 0;
tsteps = length(irrad_time);
dc_pwr = dc_power/mean(dc_power)*mean(irrad_time/1000*pv_cap)*dc_ratio;

% Flexibility
p = 0.5;

total_ranges = 0;

for i = 1:tsteps 
    temp_case = pwr_case;
    temp_case.bus(:,[3,4]) = pct_load(i) * temp_case.bus(:,[3,4]);
    
    pct_flux = irrad_time(i)/1000;
    pv_pwr = pct_flux*pv_cap; 
    
    % Set up PV and DC bus loads
    temp_case.bus(pvBus,3) = temp_case.bus(pvBus,3) - pv_pwr; 
    
    % Bounds of DC
    upperBound = dc_cap;
    lowerBound = (1-p)*dc_pwr(i);
    
    total_ranges = total_ranges + (upperBound - lowerBound);

    maxVoltage = temp_case.bus(1,12);
    minVoltage = temp_case.bus(1,13);

    % Select n evenly distributed loads between the bounds of DC
    selectedLoadsForDC = ((upperBound - lowerBound)/numLoads).*[1,2,3,4,5,6,7,8,9,10] + lowerBound;
    
    violations = zeros(1,length(selectedLoadsForDC));
    
    previousLoad = 0;
    for idx = 1:length(selectedLoadsForDC)
        temp_case.bus(dcBus,3) = temp_case.bus(dcBus,3) - previousLoad;
        temp_case.bus(dcBus,3) = temp_case.bus(dcBus,3) + selectedLoadsForDC(idx);
        
        [newResults, success] = runpf(temp_case, options);
        if success == 0
            sprintf('Convergence failure: PV_capacity = %d, time = %d',...
                pv_cap, i);
            break;
        end
        
        currentResults = newResults;
        violatedBuses = findViolated(currentResults.bus(:,8), maxVoltage, minVoltage);
        violations(idx) = length(violatedBuses);
        previousLoad = selectedLoadsForDC(idx);
    end
    
%     fprintf('Iteration: %d', i);
%     disp(violations);
    smallestViolations = min(violations);
    out_bounds = out_bounds + smallestViolations;
end

    fracInBounds = (tsteps*numBuses - out_bounds) / (tsteps*numBuses);
    avg_cap = total_ranges / tsteps;
end
