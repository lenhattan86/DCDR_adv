function [fracInBounds, out_bounds] = nonviolationfraction(pwr_case, pv_cap, irrad_time,...
    pct_load, options, storageCap, withStorage, storageBus, numBuses)

pvBus = 7;
numUsages = 10;

out_bounds = 0;
tsteps = length(irrad_time);

currentStorageLoad = 0;

for i = 1:tsteps
%     fprintf('Iteration: %d\n', i);
%     fprintf('Current Number of Violations: %d\n', out_bounds);
    
    temp_case = pwr_case;
    temp_case.bus(:,[3,4]) = pct_load(i) * temp_case.bus(:,[3,4]);
    
    pct_flux = irrad_time(i)/1000;
    pv_pwr = pct_flux*pv_cap;
    temp_case.bus(pvBus,3) = temp_case.bus(pvBus,3) - pv_pwr;
 
    v_hi = temp_case.bus(1,12);
    v_lo = temp_case.bus(1,13);

    if withStorage
        upperBound = storageCap - currentStorageLoad;
        lowerBound = -currentStorageLoad;

        selectedUsages = ((upperBound - lowerBound)/numUsages).*[1,2,3,4,5,6,7,8,9,10] + lowerBound;
        violations = zeros(1, length(selectedUsages));

        previousUsage = 0;
        for idx = 1:length(selectedUsages)
            temp_case.bus(storageBus,3) = temp_case.bus(storageBus,3) - previousUsage;
            temp_case.bus(storageBus,3) = temp_case.bus(storageBus,3) + selectedUsages(idx);

            [newResults, success] = runpf(temp_case, options);
            if success == 0
                sprintf('Convergence failure: PV_capacity = %d, time = %d',...
                    pv_cap, i);
                break;
            end
            
            violatedBuses = findViolated(newResults.bus(:,8), v_hi, v_lo); 
            violations(idx) = length(violatedBuses);
            previousUsage = selectedUsages(idx);
        end

        [smallestViolation, idx_smallestViolation] = min(violations);
        out_bounds = out_bounds + smallestViolation;

        choosenUsage = selectedUsages(idx_smallestViolation);
        currentStorageLoad = currentStorageLoad + choosenUsage;
        
        % L(t) must be in the range of 0 and C
        if (currentStorageLoad > storageCap)
            currentStorageLoad = storageCap;
        elseif (currentStorageLoad < 0)
            currentStorageLoad = 0;
        end
    else
        [results, success] = runpf(temp_case, options);
        if success == 0
            break;
        end

        out_bounds = out_bounds + length(findViolated(results.bus(:,8), v_hi, v_lo));
    end
end

    fracInBounds = (tsteps*numBuses - out_bounds) / (tsteps*numBuses);
end
