load testdayirrad.mat

% Change stuff here
power_case = case9;
numBuses = 9;

opt = mpoption('VERBOSE', 0, 'OUT_ALL', 0); % Verbose = 0 suppresses
% convergence printed output, out_all = 0 suppresses printed results of pf
% analysis

pv_cap = 280;
storageCap = 0;

% storageBus = 1:1:numBuses;
storageBus = 7;
fracinbounds = zeros(1,length(storageBus));
busoutbounds = zeros(1,length(storageBus));

% No storage case
[noStorage_fracinbounds, noStorage_busoutbounds] = nonviolationfraction(power_case, pv_cap,...
        Feb26Irrad, minuteloadFeb2012(36001:37440), opt, storageCap, false,...
        storageBus(1), numBuses);

for b = 1:length(storageBus)
    tic
    [fracinbounds(b), busoutbounds(b)] = nonviolationfraction(power_case, pv_cap,...
        Feb26Irrad, minuteloadFeb2012(36001:37440), opt, storageCap, true,...
        storageBus(b), numBuses); % Feb 26, 2013
    toc
    fprintf('Storage bus: %d \n Storage Cap: %d \n Non-Viol Frac: %d |\n Num Viol: %d \n',...
        storageBus(b), storageCap, fracinbounds(b), busoutbounds(b));
end

xlim([0,numBuses + 1])
x = 0:0.05:10;
y = noStorage_fracinbounds*ones(1,length(x));

disp('Non-violation Fractions:');
disp(fracinbounds)
disp('Number of Violations:');
disp(busoutbounds)
[minViolations, minIdx] = max(fracinbounds);
fprintf('Optimal storage location at bus: %d', minIdx);

% Plots
hold on
plot(storageBus(:),fracinbounds(:), 'ro')
plot(x,y,'-b');
xlabel('Location of Storage Bus');
ylabel('Non-Violation Fraction');
